# Portafolio Segovia — Instrucciones

## Estructura de carpetas en GitHub

Sube exactamente esta estructura:

```
tu-repositorio/
├── index.html
└── assets/
    └── images/
        ├── hero.jpg        ← imagen de portada (hero derecha)
        ├── obra-01.jpg     ← galería pieza 1 (grande izquierda)
        ├── obra-02.jpg     ← galería pieza 2
        ├── obra-03.jpg     ← galería pieza 3
        ├── obra-04.jpg     ← galería pieza 4
        ├── obra-05.jpg     ← galería pieza 5
        ├── obra-06.jpg     ← galería pieza 6
        ├── obra-07.jpg     ← galería pieza 7
        ├── musica-01.jpg   ← sección música foto 1
        ├── musica-02.jpg   ← sección música foto 2
        ├── musica-03.jpg   ← sección música foto 3
        └── perfil.jpg      ← tu foto de perfil (sección "sobre mí")
```

## Cómo subir en GitHub

1. Entra a tu repositorio en github.com
2. Haz clic en **"Add file" → "Upload files"**
3. Primero sube el `index.html`
4. Luego crea la carpeta `assets/images/`:
   - Haz clic en "Add file" → "Upload files"
   - Arrastra tus imágenes
   - En el campo de ruta escribe `assets/images/` antes del nombre
5. Confirma con **"Commit changes"**

## Formatos recomendados

- Imágenes: **JPG o PNG**, máximo 2MB cada una
- Resolución: mínimo 1200px de ancho para que se vean bien
- Horizontal para obra, vertical para perfil

## Personalizar textos

Abre `index.html` y busca los comentarios:
- `<!-- EDITA TU BIO AQUÍ ↓ -->` → tu texto de "sobre mí"
- `<!-- CAMBIA EL EMAIL AQUÍ ↓ -->` → tu email real
- `<!-- CAMBIA LOS LINKS DE REDES AQUÍ ↓ -->` → tus redes
- Los nombres de proyectos musicales están marcados con `Nombre del proyecto musical`

## Activar GitHub Pages

1. En tu repositorio → **Settings**
2. Sidebar izquierda → **Pages**
3. Source: **Deploy from a branch**
4. Branch: **main** → carpeta: **/ (root)**
5. Guardar → en 2-3 min tu URL estará activa
